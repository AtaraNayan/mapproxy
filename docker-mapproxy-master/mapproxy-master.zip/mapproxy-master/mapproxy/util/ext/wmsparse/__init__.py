from .parse import parse_capabilities

__all__ = ['parse_capabilities']